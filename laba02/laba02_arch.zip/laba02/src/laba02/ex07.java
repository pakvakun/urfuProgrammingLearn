package laba02;

public class ex07 {
	
	public static void main(String[] args) {
		
		ex02.main(null);
		
	}
	
}
