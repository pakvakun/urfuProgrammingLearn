package laba02;


public class ex06 {

	public static void main(String[] args) {
		ex01.main(null);
	}

}
