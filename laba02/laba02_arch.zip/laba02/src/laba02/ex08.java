package laba02;

public class ex08 {

	public static void main(String[] args) {
		
		ex03.main(null);
		
	}
	
}
