package laba02;

public class ex09 {
	
	public static void main(String[] args) {
		
		ex04.main(null);
		
	}
}
